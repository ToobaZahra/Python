import os
import platform
from auction_art import logo

def clear():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')

print(logo)

bidders = {}

is_end = False
while not is_end:
    name = input("What is your name: ")
    bid = int(input("What is your bid: $"))
    bidders[name] = bid
    choice = input("Are there any other bidders? Type 'yes' or 'no': ").lower()
    if choice == 'no':
        is_end = True
    clear()

# Find the highest bidder
max_bid = 0
winner = ""
for bidder in bidders:
    if bidders[bidder] > max_bid:
        max_bid = bidders[bidder]
        winner = bidder

print(f"The winner is {winner} with a bid of ${max_bid}")
