import random
import os
import blackjack_game_art

from blackjack_game_art import logo
print(logo)

# List of card values
cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]

# Function to deal a card
def deal_card():
    return random.choice(cards)

# Function to calculate the score
def calculate_score(card_list):
    score = sum(card_list)
    # If the score is over 21 and there's an ace in the hand, reduce the ace from 11 to 1
    while 11 in card_list and score > 21:
        card_list.remove(11)
        card_list.append(1)
        score = sum(card_list)
    return score

# Function to determine if there is a blackjack
def check_blackjack(card_list):
    return sum(card_list) == 21 and len(card_list) == 2

# Function to clear the console
def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

# Main game loop
def play_blackjack():
    user_cards = [deal_card(), deal_card()]
    computer_cards = [deal_card(), deal_card()]

    user_score = calculate_score(user_cards)
    computer_score = calculate_score(computer_cards)

    user_blackjack = check_blackjack(user_cards)
    computer_blackjack = check_blackjack(computer_cards)

    print(f"User cards: {user_cards}, User score: {user_score}")
    print(f"Computer's first card: {computer_cards[0]}")

    if computer_blackjack:
        print("Computer has blackjack! You lose.")
    elif user_blackjack:
        print("You have blackjack! You win.")
    else:
        game_over = False
        while not game_over:
            another_card = input("Do you want another card? Type 'y' for yes or 'n' for no: ").lower()
            if another_card == 'y':
                user_cards.append(deal_card())
                user_score = calculate_score(user_cards)
                print(f"Your cards: {user_cards}, Your score: {user_score}")
                if user_score > 21:
                    game_over = True
                    print("Your score went over 21. You lose.")
            else:
                game_over = True

        if user_score <= 21:
            while computer_score < 17:
                computer_cards.append(deal_card())
                computer_score = calculate_score(computer_cards)
            print(f"Computer's cards: {computer_cards}, Computer's score: {computer_score}")

            if computer_score > 21:
                print("Computer's score went over 21. You win.")
            elif user_score > computer_score:
                print("You win!")
            elif user_score < computer_score:
                print("You lose.")
            else:
                print("It's a draw!")

    print(f"Your final hand: {user_cards}, final score: {user_score}")
    print(f"Computer's final hand: {computer_cards}, final score: {computer_score}")

while True:
    play_blackjack()
    replay = input("Do you want to play again? Type 'y' for yes or 'n' for no: ").lower()
    if replay != 'y':
        break
    clear_console()
