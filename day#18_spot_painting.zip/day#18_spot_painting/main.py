from turtle import Turtle, Screen
import random

t = Turtle()
screen = Screen()

colors_list = [(200, 162, 99), (61, 91, 130), (139, 170, 192), (138, 90, 46), (220, 207, 115), (138, 25, 51),
               (32, 41, 67), (79, 15, 36), (170, 155, 45), (151, 58, 85), (187, 142, 161), (133, 184, 145),
               (45, 54, 103), (185, 93, 106), (56, 39, 26), (94, 117, 171)]

screen.colormode(255)
t.hideturtle()


def spot_painting():
    t.speed("fastest")
    for i in range(1, 11):
        t.color(random.choice(colors_list))
        t.dot(size=20)
        t.penup()
        t.forward(30)
    t.right(270)
    t.penup()
    t.forward(30)
    t.right(270)
    t.forward(30)
    for j in range(1, 11):
        t.penup()
        t.forward(30)
    t.right(180)
    t.forward(30)


for dot in range(1, 11):
    spot_painting()

screen.exitonclick()
