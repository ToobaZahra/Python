from art import higher_lower, vs
from game_data import data
import random
print(higher_lower)


# 1: Show a random personality from dict as 'A'
# 2: Show another random personality from dict as 'B'
# 3: Ask the user to find which one has higher followers
# 4: Compare the followers
# 5: If user was right, now make the correct answer as 'A' and get the random personality as 'B'
# 6: If user was wrong, end the game


def random_personality():
    a = random.choice(data)
    b = random.choice(data)
    return a,b

def find_followers(a,b):
    a_followers = a['follower_count']
    b_followers = b['follower_count']
    return a_followers,b_followers

def get_max_follower_person(a,b):
    if a['follower_count']> b['follower_count']:
        return a
        
    elif b['follower_count']> a['follower_count']:
        return b

game_end = False
score = 0
a,b = random_personality()
while not game_end:
        # {'name': 'Jennifer Lopez', 'follower_count': 119,
    # 'description': 'Musician and actress', 'country': 'United States'}

    print(f"Compare A: {a['name']} a {a['description']} from {a['country']}.")
    print(vs)
    print(f"Against B: {b['name']} a {b['description']} from {b['country']}.")
    
    choice = input("Who has more followers: Type 'A' or 'B': ").lower()

    a_followers,b_followers = find_followers(a,b)

    if (choice == 'a' and a_followers > b_followers) or (choice == 'b' and b_followers > a_followers):
        score+=1
        print(f"You're right! Current score is {score}")
        a = get_max_follower_person(a,b)
        b= random.choice(data)
        while b==a:
            b = random.choice(data)
    
    else:
        print("You're wrong!")
        game_end = True
    
    

