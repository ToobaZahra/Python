import os
import platform
from calculator_art import logo


def clear():
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')
def add(n1,n2):
  return n1+n2

def subtract(n1,n2):
  return n1-n2

def multiply(n1,n2):
  return n1*n2

def divide(n1,n2):
  return n1/n2

operations = {
  '+' : add,
  '-' : subtract,
  '*' : multiply,
  '/' : divide,
}
def  calculator():
  print(logo)
  num1 = float(input("What is the first number? "))
  for key in operations:
    print(key)

  is_end = False
  while not is_end:
    operation_symbol = input("Pick an operation from line above? ")
    num2 = float(input("What is the next number? "))
    calculation_function = operations[operation_symbol]
    answer = calculation_function(num1,num2)
    print(f"{num1} {operation_symbol} {num2} = {answer}")
    
    choice = input(f"Type 'y' to continue calculating with {answer} or  type 'n' to exit: ")
    
    if choice == 'y':
     num1 = answer 
    elif choice == 'n':
      is_end = True
      clear()
      calculator()
  
  
calculator()