#Number Guessing Game Objectives:

import random
# Include an ASCII art logo.
from art import logo
print(logo)

# Allow the player to submit a guess for a number between 1 and 100.
print("Welcome to Number Guessing Game.")
print("I'm thinking of a number between 1 and 100.")
choice = input("Choose a difficulty. Type 'easy'or 'hard: ").lower()
random_number = random.randint(1,101)
print(random_number)
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer.
program_end = False
while not program_end:
    game_end = False
    if choice == 'easy':
        easy_attempts = 11
        while not game_end:
            easy_attempts = easy_attempts-1
            if easy_attempts !=0:   
                print(f'You have {easy_attempts} attempts left')
                number = int(input("Make a guess: "))
                if number >random_number:
                    print('Too high')
                elif number < random_number:
                    print('Too Low')
                # If they got the answer correct, show the actual answer to the player.
                elif number == random_number:
                    print(f"✨You got it. The answer was {random_number}🎉")
                    game_end = True
                    program_end = True
                    
            else:
                print('You have run out of guess.You lose!')
                game_end = True
                program_end = True
                
                
    elif choice == 'hard':
        hard_attempts = 6
        while not game_end:
            hard_attempts = hard_attempts-1
            if hard_attempts !=0:   
                print(f'You have {hard_attempts} attempts left')
                number = int(input("Make a guess: "))
                if number >random_number:
                    print('Too high')
                    print('Guess again.')
                elif number < random_number:
                    print('Too Low')
                    print('Guess again.')

                # If they got the answer correct, show the actual answer to the player.
                elif number == random_number:
                    print(f"✨You got it. The answer was {random_number}🎉")
                    game_end = True
                    program_end = True
            else:
                print('You have run out of guess.You lose!')
                game_end = True
                program_end = True
    else:
        print("Please enter either 'easy' or 'hard': ")
        program_end = True

        
    


# Track the number of turns remaining.
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).